package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class FeedbackController {
	@Autowired
	FeedbackDao dao;
	@PostMapping("/insert")
	public Feedback insert(@RequestBody Feedback f) {
		return dao.insert(f);
	}

@PostMapping("/insertall")
public List<Feedback> insertall(@RequestBody List<Feedback> f){
	return dao.insertall(f);
}


@GetMapping("/getall")
public List<Feedback> getall(){
	return dao.getall();
}
@GetMapping("/getbyid/{id}")
public Feedback getbyid(@PathVariable int id) throws ResourceNotFoundException {
	return dao.getbyid(id).orElseThrow(()->new ResourceNotFoundException("id value is not found"));
}


}
